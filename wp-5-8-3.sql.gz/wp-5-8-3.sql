-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Jan 10, 2022 at 12:09 PM
-- Server version: 5.7.34
-- PHP Version: 7.4.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wp-5-8-1`
--

-- --------------------------------------------------------

--
-- Table structure for table `wp_commentmeta`
--

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `comment_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_comments`
--

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) UNSIGNED NOT NULL,
  `comment_post_ID` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_comments`
--

INSERT INTO `wp_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Een WordPress commentator', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2021-11-02 09:15:16', '2021-11-02 09:15:16', 'Hoi, dit is een reactie.\nOm te beginnen met beheren, bewerken en verwijderen van reacties, ga je naar het Reacties scherm op het dashboard.\nAvatars van auteurs komen van <a href=\"https://gravatar.com\">Gravatar</a>.', 0, '1', '', 'comment', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_links`
--

CREATE TABLE `wp_links` (
  `link_id` bigint(20) UNSIGNED NOT NULL,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_options`
--

CREATE TABLE `wp_options` (
  `option_id` bigint(20) UNSIGNED NOT NULL,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_options`
--

INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'https://boilerplate:8890', 'yes'),
(2, 'home', 'https://boilerplate:8890', 'yes'),
(3, 'blogname', 'Boilerplate', 'yes'),
(4, 'blogdescription', 'WordPress 5.8.1', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'webbeheer@bureauhanze.nl', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'j F Y', 'yes'),
(24, 'time_format', 'H:i', 'yes'),
(25, 'links_updated_date_format', 'j F Y H:i', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:116:{s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:17:\"^wp-sitemap\\.xml$\";s:23:\"index.php?sitemap=index\";s:17:\"^wp-sitemap\\.xsl$\";s:36:\"index.php?sitemap-stylesheet=sitemap\";s:23:\"^wp-sitemap-index\\.xsl$\";s:34:\"index.php?sitemap-stylesheet=index\";s:48:\"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$\";s:75:\"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]\";s:34:\"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$\";s:47:\"index.php?sitemap=$matches[1]&paged=$matches[2]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:37:\"projecten/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:47:\"projecten/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:67:\"projecten/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:62:\"projecten/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:62:\"projecten/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:43:\"projecten/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:26:\"projecten/([^/]+)/embed/?$\";s:42:\"index.php?projecten=$matches[1]&embed=true\";s:30:\"projecten/([^/]+)/trackback/?$\";s:36:\"index.php?projecten=$matches[1]&tb=1\";s:38:\"projecten/([^/]+)/page/?([0-9]{1,})/?$\";s:49:\"index.php?projecten=$matches[1]&paged=$matches[2]\";s:45:\"projecten/([^/]+)/comment-page-([0-9]{1,})/?$\";s:49:\"index.php?projecten=$matches[1]&cpage=$matches[2]\";s:34:\"projecten/([^/]+)(?:/([0-9]+))?/?$\";s:48:\"index.php?projecten=$matches[1]&page=$matches[2]\";s:26:\"projecten/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:36:\"projecten/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:56:\"projecten/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:51:\"projecten/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:51:\"projecten/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:32:\"projecten/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:57:\"project-category/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:55:\"index.php?project_category=$matches[1]&feed=$matches[2]\";s:52:\"project-category/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:55:\"index.php?project_category=$matches[1]&feed=$matches[2]\";s:33:\"project-category/([^/]+)/embed/?$\";s:49:\"index.php?project_category=$matches[1]&embed=true\";s:45:\"project-category/([^/]+)/page/?([0-9]{1,})/?$\";s:56:\"index.php?project_category=$matches[1]&paged=$matches[2]\";s:27:\"project-category/([^/]+)/?$\";s:38:\"index.php?project_category=$matches[1]\";s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:13:\"favicon\\.ico$\";s:19:\"index.php?favicon=1\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:27:\"comment-page-([0-9]{1,})/?$\";s:38:\"index.php?&page_id=2&cpage=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";s:27:\"[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\"[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\"[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"([^/]+)/embed/?$\";s:37:\"index.php?name=$matches[1]&embed=true\";s:20:\"([^/]+)/trackback/?$\";s:31:\"index.php?name=$matches[1]&tb=1\";s:40:\"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:35:\"([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:28:\"([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&paged=$matches[2]\";s:35:\"([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&cpage=$matches[2]\";s:24:\"([^/]+)(?:/([0-9]+))?/?$\";s:43:\"index.php?name=$matches[1]&page=$matches[2]\";s:16:\"[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:26:\"[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:46:\"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:22:\"[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:3:{i:0;s:34:\"advanced-custom-fields-pro/acf.php\";i:1;s:36:\"contact-form-7-honeypot/honeypot.php\";i:2;s:36:\"contact-form-7/wp-contact-form-7.php\";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'bureauhanze', 'yes'),
(41, 'stylesheet', 'bureauhanze', 'yes'),
(42, 'comment_registration', '0', 'yes'),
(43, 'html_type', 'text/html', 'yes'),
(44, 'use_trackback', '0', 'yes'),
(45, 'default_role', 'subscriber', 'yes'),
(46, 'db_version', '49752', 'yes'),
(47, 'uploads_use_yearmonth_folders', '1', 'yes'),
(48, 'upload_path', '', 'yes'),
(49, 'blog_public', '0', 'yes'),
(50, 'default_link_category', '2', 'yes'),
(51, 'show_on_front', 'page', 'yes'),
(52, 'tag_base', '', 'yes'),
(53, 'show_avatars', '1', 'yes'),
(54, 'avatar_rating', 'G', 'yes'),
(55, 'upload_url_path', '', 'yes'),
(56, 'thumbnail_size_w', '150', 'yes'),
(57, 'thumbnail_size_h', '150', 'yes'),
(58, 'thumbnail_crop', '1', 'yes'),
(59, 'medium_size_w', '300', 'yes'),
(60, 'medium_size_h', '300', 'yes'),
(61, 'avatar_default', 'mystery', 'yes'),
(62, 'large_size_w', '1024', 'yes'),
(63, 'large_size_h', '1024', 'yes'),
(64, 'image_default_link_type', 'none', 'yes'),
(65, 'image_default_size', '', 'yes'),
(66, 'image_default_align', '', 'yes'),
(67, 'close_comments_for_old_posts', '0', 'yes'),
(68, 'close_comments_days_old', '14', 'yes'),
(69, 'thread_comments', '1', 'yes'),
(70, 'thread_comments_depth', '5', 'yes'),
(71, 'page_comments', '0', 'yes'),
(72, 'comments_per_page', '50', 'yes'),
(73, 'default_comments_page', 'newest', 'yes'),
(74, 'comment_order', 'asc', 'yes'),
(75, 'sticky_posts', 'a:0:{}', 'yes'),
(76, 'widget_categories', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(77, 'widget_text', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(78, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(79, 'uninstall_plugins', 'a:1:{s:36:\"contact-form-7-honeypot/honeypot.php\";s:22:\"honeypot4cf7_uninstall\";}', 'no'),
(80, 'timezone_string', 'Europe/Amsterdam', 'yes'),
(81, 'page_for_posts', '0', 'yes'),
(82, 'page_on_front', '2', 'yes'),
(83, 'default_post_format', '0', 'yes'),
(84, 'link_manager_enabled', '0', 'yes'),
(85, 'finished_splitting_shared_terms', '1', 'yes'),
(86, 'site_icon', '90', 'yes'),
(87, 'medium_large_size_w', '768', 'yes'),
(88, 'medium_large_size_h', '0', 'yes'),
(89, 'wp_page_for_privacy_policy', '3', 'yes'),
(90, 'show_comments_cookies_opt_in', '1', 'yes'),
(91, 'admin_email_lifespan', '1651396516', 'yes'),
(92, 'disallowed_keys', '', 'no'),
(93, 'comment_previously_approved', '1', 'yes'),
(94, 'auto_plugin_theme_update_emails', 'a:0:{}', 'no'),
(95, 'auto_update_core_dev', 'enabled', 'yes'),
(96, 'auto_update_core_minor', 'enabled', 'yes'),
(97, 'auto_update_core_major', 'enabled', 'yes'),
(98, 'wp_force_deactivated_plugins', 'a:0:{}', 'yes'),
(99, 'initial_db_version', '49752', 'yes'),
(100, 'wp_user_roles', 'a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:61:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}', 'yes'),
(101, 'fresh_site', '0', 'yes'),
(102, 'WPLANG', 'nl_NL', 'yes'),
(103, 'widget_block', 'a:6:{i:2;a:1:{s:7:\"content\";s:19:\"<!-- wp:search /-->\";}i:3;a:1:{s:7:\"content\";s:165:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Meest recente berichten</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->\";}i:4;a:1:{s:7:\"content\";s:228:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Recente reacties</h2><!-- /wp:heading --><!-- wp:latest-comments {\"displayAvatar\":false,\"displayDate\":false,\"displayExcerpt\":false} /--></div><!-- /wp:group -->\";}i:5;a:1:{s:7:\"content\";s:147:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Archieven</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->\";}i:6;a:1:{s:7:\"content\";s:152:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Categorieën</h2><!-- /wp:heading --><!-- wp:categories /--></div><!-- /wp:group -->\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(104, 'sidebars_widgets', 'a:2:{s:19:\"wp_inactive_widgets\";a:5:{i:0;s:7:\"block-2\";i:1;s:7:\"block-3\";i:2;s:7:\"block-4\";i:3;s:7:\"block-5\";i:4;s:7:\"block-6\";}s:13:\"array_version\";i:3;}', 'yes'),
(105, 'cron', 'a:7:{i:1641813316;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1641849316;a:4:{s:18:\"wp_https_detection\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1641892516;a:1:{s:32:\"recovery_mode_clean_expired_keys\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1641892553;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1641892557;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1641978916;a:1:{s:30:\"wp_site_health_scheduled_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}}s:7:\"version\";i:2;}', 'yes'),
(106, 'widget_pages', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(107, 'widget_calendar', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(108, 'widget_archives', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(109, 'widget_media_audio', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(110, 'widget_media_image', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(111, 'widget_media_gallery', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(112, 'widget_media_video', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(113, 'widget_meta', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(114, 'widget_search', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(115, 'widget_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(116, 'widget_nav_menu', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(117, 'widget_custom_html', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(119, 'recovery_keys', 'a:0:{}', 'yes'),
(120, 'https_detection_errors', 'a:1:{s:23:\"ssl_verification_failed\";a:1:{i:0;s:24:\"SSL verificatie mislukt.\";}}', 'yes'),
(122, 'theme_mods_twentytwentyone', 'a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1635844708;s:4:\"data\";a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:3:{i:0;s:7:\"block-2\";i:1;s:7:\"block-3\";i:2;s:7:\"block-4\";}s:9:\"sidebar-2\";a:2:{i:0;s:7:\"block-5\";i:1;s:7:\"block-6\";}}}}', 'yes'),
(137, 'can_compress_scripts', '1', 'no'),
(153, 'widget_recent-posts', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(154, 'widget_recent-comments', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(159, 'finished_updating_comment_type', '1', 'yes'),
(166, 'current_theme', 'BureauHanze', 'yes'),
(167, 'theme_mods_bureauhanze', 'a:3:{i:0;b:0;s:18:\"nav_menu_locations\";a:1:{s:4:\"main\";i:2;}s:18:\"custom_css_post_id\";i:-1;}', 'yes'),
(168, 'theme_switched', '', 'yes'),
(169, 'recently_activated', 'a:0:{}', 'yes'),
(170, 'acf_version', '5.8.7', 'yes'),
(171, 'wpcf7', 'a:2:{s:7:\"version\";s:5:\"5.5.3\";s:13:\"bulk_validate\";a:4:{s:9:\"timestamp\";i:1635844783;s:7:\"version\";s:5:\"5.5.2\";s:11:\"count_valid\";i:1;s:13:\"count_invalid\";i:0;}}', 'yes'),
(174, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}', 'yes'),
(175, 'options_contactLogo', '<svg width=\"85px\" height=\"44px\" viewBox=\"0 0 85 44\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\">\r\n    <g class=\"logo\" stroke=\"none\" stroke-width=\"1\" fill=\"currentColor\" fill-rule=\"evenodd\" font-family=\"Impact\" font-size=\"48\" font-style=\"condensed\" font-weight=\"700\">\r\n        <text id=\"logo\">\r\n            <tspan x=\"-1\" y=\"38\">logo</tspan>\r\n        </text>\r\n    </g>\r\n</svg>', 'no'),
(176, '_options_contactLogo', 'field_6179a0f70f954', 'no'),
(177, 'options_contactCompany', 'Bedrijfsnaam', 'no'),
(178, '_options_contactCompany', 'field_6179044e6bd42', 'no'),
(179, 'options_contactPhone', 'a:3:{s:5:\"title\";s:16:\"+31 85 06 40 200\";s:3:\"url\";s:16:\"tel:+31850640200\";s:6:\"target\";s:0:\"\";}', 'no'),
(180, '_options_contactPhone', 'field_6178f45566dc9', 'no'),
(181, 'options_contactMail', 'a:3:{s:5:\"title\";s:19:\"info@bureauhanze.nl\";s:3:\"url\";s:26:\"mailto:info@bureauhanze.nl\";s:6:\"target\";s:0:\"\";}', 'no'),
(182, '_options_contactMail', 'field_6178fde2cb3d0', 'no'),
(183, 'options_contactAddress', 'Straatnaam 11', 'no'),
(184, '_options_contactAddress', 'field_6178ff949ba6f', 'no'),
(185, 'options_contactPostal', '1234 AB', 'no'),
(186, '_options_contactPostal', 'field_617901e57dcd0', 'no'),
(187, 'options_contactPlace', 'Plaats', 'no'),
(188, '_options_contactPlace', 'field_617901fe7dcd1', 'no'),
(189, 'options_contactCountry', 'Nederland', 'no'),
(190, '_options_contactCountry', 'field_6179022a7dcd3', 'no'),
(192, 'project_category_children', 'a:0:{}', 'yes'),
(198, '_transient_health-check-site-status-result', '{\"good\":11,\"recommended\":7,\"critical\":1}', 'yes'),
(214, 'options_contactFavicon', '95', 'no'),
(215, '_options_contactFavicon', 'field_61839829b75c6', 'no'),
(216, 'options_contactSlogan', 'WordPress webdevelopment', 'no'),
(217, '_options_contactSlogan', 'field_6183993918c48', 'no'),
(218, 'options_contactURL', 'https://bureauhanze.nl', 'no'),
(219, '_options_contactURL', 'field_618396f0c65bc', 'no'),
(220, 'options_contactInstagram', 'a:3:{s:5:\"title\";s:9:\"Instagram\";s:3:\"url\";s:23:\"https://instagram.com/#\";s:6:\"target\";s:6:\"_blank\";}', 'no'),
(221, '_options_contactInstagram', 'field_61ae1dd1cdbe4', 'no'),
(222, 'options_contactLinkedIn', 'a:3:{s:5:\"title\";s:8:\"LinkedIn\";s:3:\"url\";s:21:\"https://linkedin.nl/#\";s:6:\"target\";s:6:\"_blank\";}', 'no'),
(223, '_options_contactLinkedIn', 'field_61ae19337923c', 'no'),
(285, 'auto_core_update_notified', 'a:4:{s:4:\"type\";s:7:\"success\";s:5:\"email\";s:24:\"webbeheer@bureauhanze.nl\";s:7:\"version\";s:5:\"5.8.2\";s:9:\"timestamp\";i:1640269865;}', 'no'),
(381, 'options_contactFacebook', 'a:3:{s:5:\"title\";s:8:\"Facebook\";s:3:\"url\";s:22:\"https://facebook.com/#\";s:6:\"target\";s:6:\"_blank\";}', 'no'),
(382, '_options_contactFacebook', 'field_61ae1855e55de', 'no'),
(383, 'options_contactYouTube', 'a:3:{s:5:\"title\";s:7:\"YouTube\";s:3:\"url\";s:21:\"https://youtube.com/#\";s:6:\"target\";s:6:\"_blank\";}', 'no'),
(384, '_options_contactYouTube', 'field_61ae19147923b', 'no'),
(409, 'new_admin_email', 'webbeheer@bureauhanze.nl', 'yes'),
(412, 'adminhash', 'a:2:{s:4:\"hash\";s:32:\"c241dc309580a9308ddc22bf151e9fcb\";s:8:\"newemail\";s:24:\"webbeheer@bureauhanze.nl\";}', 'yes'),
(415, 'options_contactWhatsApp', 'a:3:{s:5:\"title\";s:8:\"WhatsApp\";s:3:\"url\";s:24:\"https://wa.me/3161234567\";s:6:\"target\";s:0:\"\";}', 'no'),
(416, '_options_contactWhatsApp', 'field_61af80d7ba22f', 'no'),
(564, 'secret_key', 'iyh`Ny<1uOQK<w24#Am)j<jL22<^)gG@zUD/?XGE2Eh$a_D{._~;o0Ix:V==+hw^', 'no'),
(617, 'options_contactKvK', '12345678', 'no'),
(618, '_options_contactKvK', 'field_61d5577a78ad9', 'no'),
(619, 'options_contactBTW', '12345678', 'no'),
(620, '_options_contactBTW', 'field_61d557a978ada', 'no'),
(633, 'honeypot4cf7_config', 'a:12:{s:14:\"store_honeypot\";i:0;s:11:\"placeholder\";s:0:\"\";s:21:\"accessibility_message\";s:0:\"\";s:22:\"w3c_valid_autocomplete\";a:1:{i:0;s:5:\"false\";}s:15:\"move_inline_css\";a:1:{i:0;s:5:\"false\";}s:9:\"nomessage\";a:1:{i:0;s:5:\"false\";}s:17:\"timecheck_enabled\";a:1:{i:0;s:5:\"false\";}s:15:\"timecheck_value\";s:1:\"4\";s:14:\"honeypot_count\";i:0;s:21:\"honeypot_install_date\";i:1641379890;s:30:\"honeypot_cf7_req_msg_dismissed\";i:0;s:20:\"honeypot4cf7_version\";s:3:\"2.1\";}', 'yes'),
(642, '_site_transient_timeout_browser_8ffec38781748c07c6d2e71b451e2e28', '1642081743', 'no'),
(643, '_site_transient_browser_8ffec38781748c07c6d2e71b451e2e28', 'a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:13:\"96.0.4664.110\";s:8:\"platform\";s:9:\"Macintosh\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}', 'no'),
(644, '_site_transient_timeout_php_check_20f4df878f211a5689e76acb3f9067a8', '1642081743', 'no'),
(645, '_site_transient_php_check_20f4df878f211a5689e76acb3f9067a8', 'a:5:{s:19:\"recommended_version\";s:3:\"7.4\";s:15:\"minimum_version\";s:6:\"5.6.20\";s:12:\"is_supported\";b:1;s:9:\"is_secure\";b:1;s:13:\"is_acceptable\";b:1;}', 'no'),
(660, '_transient_timeout_acf_plugin_updates', '1641980662', 'no'),
(661, '_transient_acf_plugin_updates', 'a:4:{s:7:\"plugins\";a:1:{s:34:\"advanced-custom-fields-pro/acf.php\";a:8:{s:4:\"slug\";s:26:\"advanced-custom-fields-pro\";s:6:\"plugin\";s:34:\"advanced-custom-fields-pro/acf.php\";s:11:\"new_version\";s:6:\"5.11.4\";s:3:\"url\";s:36:\"https://www.advancedcustomfields.com\";s:6:\"tested\";s:5:\"5.8.1\";s:7:\"package\";s:0:\"\";s:5:\"icons\";a:1:{s:7:\"default\";s:63:\"https://ps.w.org/advanced-custom-fields/assets/icon-256x256.png\";}s:7:\"banners\";a:2:{s:3:\"low\";s:77:\"https://ps.w.org/advanced-custom-fields/assets/banner-772x250.jpg?rev=1729102\";s:4:\"high\";s:78:\"https://ps.w.org/advanced-custom-fields/assets/banner-1544x500.jpg?rev=1729099\";}}}s:10:\"expiration\";i:172800;s:6:\"status\";i:1;s:7:\"checked\";a:1:{s:34:\"advanced-custom-fields-pro/acf.php\";s:5:\"5.8.7\";}}', 'no'),
(666, '_site_transient_update_themes', 'O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1641812921;s:7:\"checked\";a:1:{s:11:\"bureauhanze\";s:3:\"0.1\";}s:8:\"response\";a:0:{}s:9:\"no_update\";a:0:{}s:12:\"translations\";a:0:{}}', 'no'),
(667, '_site_transient_update_plugins', 'O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1641812920;s:8:\"response\";a:1:{s:34:\"advanced-custom-fields-pro/acf.php\";O:8:\"stdClass\":8:{s:4:\"slug\";s:26:\"advanced-custom-fields-pro\";s:6:\"plugin\";s:34:\"advanced-custom-fields-pro/acf.php\";s:11:\"new_version\";s:6:\"5.11.4\";s:3:\"url\";s:36:\"https://www.advancedcustomfields.com\";s:6:\"tested\";s:5:\"5.8.1\";s:7:\"package\";s:0:\"\";s:5:\"icons\";a:1:{s:7:\"default\";s:63:\"https://ps.w.org/advanced-custom-fields/assets/icon-256x256.png\";}s:7:\"banners\";a:2:{s:3:\"low\";s:77:\"https://ps.w.org/advanced-custom-fields/assets/banner-772x250.jpg?rev=1729102\";s:4:\"high\";s:78:\"https://ps.w.org/advanced-custom-fields/assets/banner-1544x500.jpg?rev=1729099\";}}}s:12:\"translations\";a:2:{i:0;a:7:{s:4:\"type\";s:6:\"plugin\";s:4:\"slug\";s:14:\"contact-form-7\";s:8:\"language\";s:5:\"nl_NL\";s:7:\"version\";s:5:\"5.5.3\";s:7:\"updated\";s:19:\"2021-12-08 11:39:56\";s:7:\"package\";s:81:\"https://downloads.wordpress.org/translation/plugin/contact-form-7/5.5.3/nl_NL.zip\";s:10:\"autoupdate\";b:1;}i:1;a:7:{s:4:\"type\";s:6:\"plugin\";s:4:\"slug\";s:23:\"contact-form-7-honeypot\";s:8:\"language\";s:5:\"nl_NL\";s:7:\"version\";s:3:\"2.1\";s:7:\"updated\";s:19:\"2021-10-05 08:42:14\";s:7:\"package\";s:88:\"https://downloads.wordpress.org/translation/plugin/contact-form-7-honeypot/2.1/nl_NL.zip\";s:10:\"autoupdate\";b:1;}}s:9:\"no_update\";a:3:{s:36:\"contact-form-7/wp-contact-form-7.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:28:\"w.org/plugins/contact-form-7\";s:4:\"slug\";s:14:\"contact-form-7\";s:6:\"plugin\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:11:\"new_version\";s:5:\"5.5.3\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/contact-form-7/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/contact-form-7.5.5.3.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:67:\"https://ps.w.org/contact-form-7/assets/icon-256x256.png?rev=2279696\";s:2:\"1x\";s:59:\"https://ps.w.org/contact-form-7/assets/icon.svg?rev=2339255\";s:3:\"svg\";s:59:\"https://ps.w.org/contact-form-7/assets/icon.svg?rev=2339255\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/contact-form-7/assets/banner-1544x500.png?rev=860901\";s:2:\"1x\";s:68:\"https://ps.w.org/contact-form-7/assets/banner-772x250.png?rev=880427\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"5.7\";}s:36:\"contact-form-7-honeypot/honeypot.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:37:\"w.org/plugins/contact-form-7-honeypot\";s:4:\"slug\";s:23:\"contact-form-7-honeypot\";s:6:\"plugin\";s:36:\"contact-form-7-honeypot/honeypot.php\";s:11:\"new_version\";s:3:\"2.1\";s:3:\"url\";s:54:\"https://wordpress.org/plugins/contact-form-7-honeypot/\";s:7:\"package\";s:66:\"https://downloads.wordpress.org/plugin/contact-form-7-honeypot.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:76:\"https://ps.w.org/contact-form-7-honeypot/assets/icon-256x256.png?rev=2487322\";s:2:\"1x\";s:76:\"https://ps.w.org/contact-form-7-honeypot/assets/icon-128x128.png?rev=2487322\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:79:\"https://ps.w.org/contact-form-7-honeypot/assets/banner-1544x500.jpg?rev=2487322\";s:2:\"1x\";s:78:\"https://ps.w.org/contact-form-7-honeypot/assets/banner-772x250.jpg?rev=2487322\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"4.8\";}s:47:\"regenerate-thumbnails/regenerate-thumbnails.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:35:\"w.org/plugins/regenerate-thumbnails\";s:4:\"slug\";s:21:\"regenerate-thumbnails\";s:6:\"plugin\";s:47:\"regenerate-thumbnails/regenerate-thumbnails.php\";s:11:\"new_version\";s:5:\"3.1.5\";s:3:\"url\";s:52:\"https://wordpress.org/plugins/regenerate-thumbnails/\";s:7:\"package\";s:70:\"https://downloads.wordpress.org/plugin/regenerate-thumbnails.3.1.5.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:74:\"https://ps.w.org/regenerate-thumbnails/assets/icon-128x128.png?rev=1753390\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:77:\"https://ps.w.org/regenerate-thumbnails/assets/banner-1544x500.jpg?rev=1753390\";s:2:\"1x\";s:76:\"https://ps.w.org/regenerate-thumbnails/assets/banner-772x250.jpg?rev=1753390\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"4.7\";}}}', 'no'),
(669, '_site_transient_timeout_theme_roots', '1641814625', 'no'),
(670, '_site_transient_theme_roots', 'a:1:{s:11:\"bureauhanze\";s:7:\"/themes\";}', 'no'),
(673, '_site_transient_update_core', 'O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:65:\"https://downloads.wordpress.org/release/nl_NL/wordpress-5.8.3.zip\";s:6:\"locale\";s:5:\"nl_NL\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:65:\"https://downloads.wordpress.org/release/nl_NL/wordpress-5.8.3.zip\";s:10:\"no_content\";s:0:\"\";s:11:\"new_bundled\";s:0:\"\";s:7:\"partial\";s:0:\"\";s:8:\"rollback\";s:0:\"\";}s:7:\"current\";s:5:\"5.8.3\";s:7:\"version\";s:5:\"5.8.3\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.6\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1641812922;s:15:\"version_checked\";s:5:\"5.8.3\";s:12:\"translations\";a:0:{}}', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `wp_postmeta`
--

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_postmeta`
--

INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'template-main.php'),
(5, 2, '_edit_lock', '1639087728:3'),
(9, 2, '_edit_last', '3'),
(10, 9, '_form', '<div class=\"form-col\">\n  [honeypot honeypot-208 id:email]\n</div>\n\n<div class=\"form-col\">\n  [text* first_name id:first_name]\n  <label for=\"first_name\">Voornaam</label>\n</div>\n\n<div class=\"form-col\">\n  [text* last_name id:last_name]\n  <label for=\"last_name\">Achternaam</label>\n</div>\n\n<div class=\"form-col\">\n  [tel* phone id:phone]\n  <label for=\"phone\">Telefoonnummer</label>\n</div>\n\n<div class=\"form-col\">\n  [email* email_real id:email_real]\n  <label for=\"email_real\">E-mail adres</label>\n</div>\n\n<div class=\"form-col\">\n  [text* subject id:subject]\n  <label for=\"subject\">Onderwerp</label>\n</div>\n\n<div class=\"form-col form-textarea-col\">\n  [textarea* message id:message]\n  <label for=\"message\">Bericht</label>\n</div>\n\n<div class=\"form-col form-submit-col\">\n  [submit \"Submit\"]\n</div>'),
(11, 9, '_mail', 'a:9:{s:6:\"active\";b:1;s:7:\"subject\";s:25:\"[_site_title] \"[subject]\"\";s:6:\"sender\";s:40:\"[_site_title] <webbeheer@bureauhanze.nl>\";s:9:\"recipient\";s:19:\"[_site_admin_email]\";s:4:\"body\";s:8776:\"<html lang=\"en\">\n<head>\n    <meta charset=\"UTF-8\">\n    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n    <title>E-mail template</title>\n    <link rel=\"preconnect\" href=\"https://fonts.googleapis.com\">\n    <link rel=\"preconnect\" href=\"https://fonts.gstatic.com\" crossorigin>\n    <link href=\"https://fonts.googleapis.com/css2?family=Open+Sans&display=swap\" rel=\"stylesheet\">\n</head>\n<body>\n    \n\n<div class=\"page-wrapper\">\n\n    <header class=\"header\">\n        <div class=\"container\">\n            <div class=\"row\">\n                <img class=\"header-logo\" src=\"/wp-content/themes/bureauhanze/assets/img/favicon.jpg\" alt=\"Favicon\">\n            </div>\n        </div>\n    </header>\n    \n    <div class=\"sender-information\">\n        <div class=\"container\">\n            <div class=\"row\">\n                <h1>Nieuwe contactaanvraag.</h1>\n                <div class=\"sender-items\">\n                    <p class=\"sender-item\">Naam:</p>\n                    <p class=\"sender-result\">[first_name] [last_name]</p>\n                </div>\n                <div class=\"sender-items\">\n                    <p class=\"sender-item\">E-mail adres:</p>\n                    <p class=\"sender-result\">[email_real]</p>\n                </div>\n                <div class=\"sender-items\">\n                    <p class=\"sender-item\">Telefoonnummer:</p>\n                    <p class=\"sender-result\">[phone]</p>\n                </div>\n                <div class=\"sender-items\">\n                    <p class=\"sender-item\">Onderwerp:</p>\n                    <p class=\"sender-result\">[subject]</p>\n                </div>\n                <div class=\"sender-items\">\n                    <p class=\"sender-item sender-item-span\">Bericht:</p>\n                    <p class=\"sender-result\">[message]</p>\n                </div>\n            </div>\n        </div>\n    </div>\n\n    <div class=\"seperator\"></div>\n\n    <footer class=\"footer\">\n    \n        <div class=\"container\">\n            <div class=\"row\">\n                <div class=\"footer-contact\">\n                    <h2>Contact.</h2>\n                    <p>Broeklandstraaat 16</p>\n                    <p>8082 AE Elburg</p>\n                    <a href=\"https://bureauhanze.nl\" title=\"\">Bekijk hier onze website.</a>\n                    <div class=\"footer-buttons\">\n                        <a class=\"main-navigation__phone contact-phone\" href=\"tel:+31850640200\" target=\"\" title=\"Bel met ons\">\n                        <svg width=\"15px\" height=\"16px\" viewBox=\"0 0 15 16\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\">\n                            <title>phone-icon</title>\n                            <g id=\"Page-1\" stroke=\"none\" stroke-width=\"1\" fill=\"none\" fill-rule=\"evenodd\">\n                                <g id=\"Home\" transform=\"translate(-1034.000000, -35.000000)\" fill-rule=\"nonzero\">\n                                    <g id=\"phone-icon\" transform=\"translate(1034.000000, 35.000000)\">\n                                        <path d=\"M14.1145199,10.3069889 C14.1499391,7.75680607 13.1582013,5.41913849 11.4934986,3.6835974 L12.1310443,3.0460517 C13.0519437,4.00237026 13.7603278,5.10036563 14.2561967,6.30461863 C14.7520656,7.57971004 15,8.92563986 15,10.2715697 L14.1145199,10.3069889 Z\" class=\"phone1\" fill=\"currentcolor\"></path>\n                                        <path d=\"M11.1747258,10.2715697 C11.210145,8.5360286 10.5371801,6.94216434 9.40376548,5.77333054 L10.0413112,5.13578484 C11.387241,6.51713387 12.0956251,8.32351336 12.0602059,10.2715697 L11.1747258,10.2715697 Z\" id=\"Path\" class=\"phone2\" ></path>\n                                        <path d=\"M11.8831099,13.8843287 L11.1038874,14.6635512 C10.7142761,15.0531625 10.182988,15.2302585 9.54544231,15.1948393 C8.97873501,15.1948393 8.34118931,15.0177433 7.63280519,14.7343896 C6.25145617,14.1676823 4.76384952,13.0696869 3.4179197,11.6883379 L5.29513761,9.81112001 C6.07436014,10.5903425 6.92442108,11.2987266 7.73906281,11.8654339 L8.8724774,10.7674386 C9.22666946,10.4486657 9.79337675,10.4486657 10.1121496,10.8028578 L11.8831099,12.6446565 C12.2373019,12.9988485 12.2373019,13.5655558 11.8831099,13.8843287 Z\" class=\"phone3\"  fill=\"currentcolor\"></path>\n                                        <path d=\"M10.005892,5.13578484 C8.65996216,3.75443581 6.85358267,2.97521329 4.94094555,2.93979408 L4.94094555,3.82527423 C6.71190584,3.86069343 8.2703509,4.60449675 9.40376548,5.77333054 L10.005892,5.13578484 L10.005892,5.13578484 Z\" class=\"phone4\"  fill=\"currentcolor\"></path>\n                                        <path d=\"M8.94331581,0.850060939 C7.70364361,0.283353646 6.35771379,0 4.97636476,0 L4.97636476,0.885480145 C7.52654758,0.920899351 9.86421516,2.01889473 11.4934986,3.71901661 L12.1310443,3.0814709 C11.210145,2.12515235 10.1475688,1.38134903 8.94331581,0.850060939 Z\" class=\"phone4\"  fill=\"currentcolor\"></path>\n                                        <path d=\"M5.2242992,9.7757008 C4.44507667,8.96105907 3.73669256,8.07557892 3.20540447,7.19009878 L4.33881905,6.0921034 C4.69301111,5.73791134 4.69301111,5.20662325 4.37423826,4.85243119 L2.60327797,3.01063249 C2.21366671,2.62102123 1.68237862,2.65644043 1.36360577,2.97521329 L0.58438324,3.71901661 C-0.124000876,4.42740072 -0.194839287,5.63165372 0.407287211,7.19009878 C0.938575298,8.60686701 2.00115147,10.1653121 3.3825005,11.5820803 L3.45333891,11.6529187 L5.33055682,9.7757008 L5.2242992,9.7757008 Z\" class=\"phone6\"  fill=\"currentcolor\"></path>\n                                    </g>\n                                </g>\n                            </g>\n                        </svg>\n                        085 06 40 200\n                        </a>\n                        <a class=\"main-navigation__mail contact-mail\" href=\"mailto:webbeheer@bureauhanze.nl\" target=\"\" title=\"webbeheer@bureauhanze.nl\"><svg width=\"19px\" height=\"15px\" viewBox=\"0 0 19 15\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\">\n                            <title>Group 4</title>\n                            <g id=\"Page-1\" stroke=\"none\" stroke-width=\"1\" fill=\"none\" fill-rule=\"evenodd\">\n                                <g id=\"Home\" transform=\"translate(-1204.000000, -35.000000)\">\n                                    <g id=\"Group-4\" transform=\"translate(1213.407283, 42.809046) rotate(-9.000000) translate(-1213.407283, -42.809046) translate(1205.000000, 37.000000)\">\n                                        <polygon class=\"envelope-top\" fill=\"currentcolor\" points=\"8.40730434 7.31182735 4.36740814e-05 1.50361127 4.36740814e-05 11.6180918 16.814565 11.6180918 16.814565 1.50361127\"></polygon>\n                                        <polygon class=\"envelope-bottom\" fill=\"currentcolor\" points=\"-6.66548334e-14 -2.87804946e-14 8.40726066 5.80865282 16.8145213 -2.87804946e-14\"></polygon>\n                                    </g>\n                                </g>\n                            </g>\n                        </svg>webbeheer@bureauhanze.nl\n                        </a>\n                    </div>\n                </div>\n            </div>\n        </div>\n\n    </footer>\n\n</div>\n\n</body>\n</html>\n\n<style>\n\n* {\n    box-sizing: border-box;\n}\nbody {\n    font-family: \'Open Sans\', sans-serif;\n}\n.page-wrapper {\n    margin: 32px;\n    max-width: 640px;\n    margin-left: auto;\n    margin-right: auto;\n    box-shadow: rgba(149, 157, 165, 0.2) 0px 8px 24px;\n}\n.container {\n    width: 100%;\n    padding: 16px 64px;\n    background: white;\n}\nh1,h2 {\n    margin-top: 0;\n    font-weight: bold;\n    color: black;\n}\nh1 {\n    margin-bottom: 32px;\n    font-size: 24px;\n}\nh2 {\n    font-size: 18px;\n}\np,a {\n    font-size: 16px;\n}\np {\n    color: black;\n    margin: 0;\n    line-height: 1.3;\n}\na {\n    color: black;\n    text-decoration: none;\n}\na:hover {\n    text-decoration: underline;\n}\n.row {\n    position: relative;\n    width: 100%;\n}\nimg {\n    height: 100%;\n    width: 100%;\n}\n.seperator {\n    height: 1px;\n    width: 100%;\n    background-color: lightgray;\n    padding: 0;\n}\n.header {\n    background-color: #15191C;\n}\n.header-logo {\n    position: absolute;\n    top: 16px;\n    right: -32px;\n    height: auto;\n    object-fit: contain;\n    width: 48px;\n}\n.sender-items {\n    display: grid;\n    grid-template-columns: 150px 1fr;\n    margin-bottom: 16px;\n}\n.sender-item-span {\n    grid-column: 1 / span 2;\n}\n.sender-result {\n    font-weight: bold;\n}\n.footer-contact a {\n    margin-top: 16px;\n    display: block;\n}\n.footer-buttons {\n    display: flex;\n    gap: 32px;\n    margin-top: 16px;\n}\n.footer-buttons a svg{\n    margin-right: 8px;\n}\n@media(max-width: 768px){\n    .container {\n    padding: 32px;\n    }\n}\n@media(max-width: 576px){\n    .container {\n    padding: 16px;\n    }\n}\n</style>\";s:18:\"additional_headers\";s:22:\"Reply-To: [email_real]\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:1;s:13:\"exclude_blank\";b:0;}'),
(12, 9, '_mail_2', 'a:9:{s:6:\"active\";b:0;s:7:\"subject\";s:30:\"[_site_title] \"[your-subject]\"\";s:6:\"sender\";s:44:\"[_site_title] <bartnijenhuis@bureauhanze.nl>\";s:9:\"recipient\";s:12:\"[your-email]\";s:4:\"body\";s:116:\"Berichtinhoud:\n[your-message]\n\n-- \nDeze e-mail is verzonden vanuit het contactformulier op [_site_title] [_site_url]\";s:18:\"additional_headers\";s:29:\"Reply-To: [_site_admin_email]\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}'),
(13, 9, '_messages', 'a:22:{s:12:\"mail_sent_ok\";s:42:\"Bedankt voor je bericht. Het is verzonden.\";s:12:\"mail_sent_ng\";s:88:\"Er is een fout opgetreden bij het versturen van het bericht; probeer het later nog eens.\";s:16:\"validation_error\";s:76:\"Een of meer velden bevatten een fout; graag controleren en opnieuw proberen.\";s:4:\"spam\";s:88:\"Er is een fout opgetreden bij het versturen van het bericht; probeer het later nog eens.\";s:12:\"accept_terms\";s:72:\"Je moet de voorwaarden accepteren voordat je het bericht kunt verzenden.\";s:16:\"invalid_required\";s:22:\"Het veld is verplicht.\";s:16:\"invalid_too_long\";s:20:\"Het veld is te lang.\";s:17:\"invalid_too_short\";s:20:\"Het veld is te kort.\";s:13:\"upload_failed\";s:69:\"Er is een onbekende fout opgetreden bij het uploaden van het bestand.\";s:24:\"upload_file_type_invalid\";s:52:\"Het is niet toegestaan dit type bestand te uploaden.\";s:21:\"upload_file_too_large\";s:24:\"Het bestand is te groot.\";s:23:\"upload_failed_php_error\";s:59:\"Er is een fout opgetreden bij het uploaden van het bestand.\";s:12:\"invalid_date\";s:29:\"De datumnotatie is incorrect.\";s:14:\"date_too_early\";s:49:\"De ingevulde datum valt voor de eerst toegestane.\";s:13:\"date_too_late\";s:48:\"De ingevulde datum valt na de laatst toegestane.\";s:14:\"invalid_number\";s:29:\"De getalsnotatie is ongeldig.\";s:16:\"number_too_small\";s:58:\"Het ingevulde getal is kleiner dan het kleinst toegestane.\";s:16:\"number_too_large\";s:56:\"Het ingevulde getal is groter dan het hoogst toegestane.\";s:23:\"quiz_answer_not_correct\";s:37:\"Het antwoord op de quiz is incorrect.\";s:13:\"invalid_email\";s:39:\"Het ingevoerde e-mailadres is ongeldig.\";s:11:\"invalid_url\";s:19:\"De URL is ongeldig.\";s:11:\"invalid_tel\";s:31:\"Het telefoonnummer is ongeldig.\";}'),
(14, 9, '_additional_settings', ''),
(15, 9, '_locale', 'nl_NL'),
(20, 13, '_edit_lock', '1641372509:3'),
(21, 13, '_edit_last', '3'),
(22, 57, '_menu_item_type', 'post_type'),
(23, 57, '_menu_item_menu_item_parent', '0'),
(24, 57, '_menu_item_object_id', '2'),
(25, 57, '_menu_item_object', 'page'),
(26, 57, '_menu_item_target', ''),
(27, 57, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(28, 57, '_menu_item_xfn', ''),
(29, 57, '_menu_item_url', ''),
(31, 58, '_edit_last', '3'),
(32, 58, '_edit_lock', '1639086904:3'),
(34, 58, 'projects_image_gallery', ''),
(35, 58, '_projects_image_gallery', 'field_617a97f949672'),
(36, 58, 'project_embed', ''),
(37, 58, '_project_embed', 'field_617a9daa26965'),
(38, 59, 'projects_image_gallery', ''),
(39, 59, '_projects_image_gallery', 'field_617a97f949672'),
(40, 59, 'project_embed', ''),
(41, 59, '_project_embed', 'field_617a9daa26965'),
(96, 54, '_edit_lock', '1639087770:3'),
(105, 68, '_edit_last', '3'),
(106, 68, '_edit_lock', '1637174804:3'),
(107, 72, '_edit_last', '3'),
(108, 72, '_edit_lock', '1641382435:3'),
(109, 72, '_wp_page_template', 'default'),
(110, 22, '_edit_lock', '1638803238:3'),
(111, 22, '_edit_last', '3'),
(112, 79, '_menu_item_type', 'post_type'),
(113, 79, '_menu_item_menu_item_parent', '0'),
(114, 79, '_menu_item_object_id', '72'),
(115, 79, '_menu_item_object', 'page'),
(116, 79, '_menu_item_target', ''),
(117, 79, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(118, 79, '_menu_item_xfn', ''),
(119, 79, '_menu_item_url', ''),
(121, 57, '_wp_old_date', '2021-11-02'),
(122, 80, '_wp_attached_file', '2021/12/bureauhanze.jpeg'),
(123, 80, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:1280;s:4:\"file\";s:24:\"2021/12/bureauhanze.jpeg\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:24:\"bureauhanze-300x200.jpeg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:25:\"bureauhanze-1024x683.jpeg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:24:\"bureauhanze-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:24:\"bureauhanze-768x512.jpeg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:26:\"bureauhanze-1536x1024.jpeg\";s:5:\"width\";i:1536;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:18:\"project-card-image\";a:4:{s:4:\"file\";s:24:\"bureauhanze-578x357.jpeg\";s:5:\"width\";i:578;s:6:\"height\";i:357;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(124, 80, '_wp_attachment_image_alt', 'bureauhanze'),
(125, 2, '_thumbnail_id', '80'),
(126, 2, 'section_projects_heading', ''),
(127, 2, '_section_projects_heading', 'field_617fabb83bc00'),
(128, 2, 'section_projects_sub-heading', ''),
(129, 2, '_section_projects_sub-heading', 'field_617fabb83bc0b'),
(130, 2, 'section_projects_paragraph', ''),
(131, 2, '_section_projects_paragraph', 'field_617fabb83bc2c'),
(132, 2, 'seoPageTitle', 'Boilerplate | Home'),
(133, 2, '_seoPageTitle', 'field_618cd353e5c8b'),
(134, 2, 'seoPageMetaDescription', 'Dit is een boilerplate'),
(135, 2, '_seoPageMetaDescription', 'field_618cd3dfe5c8c'),
(136, 12, 'section_projects_heading', ''),
(137, 12, '_section_projects_heading', 'field_617fabb83bc00'),
(138, 12, 'section_projects_sub-heading', ''),
(139, 12, '_section_projects_sub-heading', 'field_617fabb83bc0b'),
(140, 12, 'section_projects_paragraph', ''),
(141, 12, '_section_projects_paragraph', 'field_617fabb83bc2c'),
(142, 12, 'seoPageTitle', ''),
(143, 12, '_seoPageTitle', 'field_618cd353e5c8b'),
(144, 12, 'seoPageMetaDescription', ''),
(145, 12, '_seoPageMetaDescription', 'field_618cd3dfe5c8c'),
(146, 81, 'section_projects_heading', ''),
(147, 81, '_section_projects_heading', 'field_617fabb83bc00'),
(148, 81, 'section_projects_sub-heading', ''),
(149, 81, '_section_projects_sub-heading', 'field_617fabb83bc0b'),
(150, 81, 'section_projects_paragraph', ''),
(151, 81, '_section_projects_paragraph', 'field_617fabb83bc2c'),
(152, 81, 'seoPageTitle', 'Boilerplate | Home'),
(153, 81, '_seoPageTitle', 'field_618cd353e5c8b'),
(154, 81, 'seoPageMetaDescription', 'Dit is een boilerplate'),
(155, 81, '_seoPageMetaDescription', 'field_618cd3dfe5c8c'),
(156, 82, '_wp_attached_file', '2021/11/specialisten_in_communicatiev2.jpeg'),
(157, 82, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1180;s:6:\"height\";i:722;s:4:\"file\";s:43:\"2021/11/specialisten_in_communicatiev2.jpeg\";s:5:\"sizes\";a:5:{s:6:\"medium\";a:4:{s:4:\"file\";s:43:\"specialisten_in_communicatiev2-300x184.jpeg\";s:5:\"width\";i:300;s:6:\"height\";i:184;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:44:\"specialisten_in_communicatiev2-1024x627.jpeg\";s:5:\"width\";i:1024;s:6:\"height\";i:627;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:43:\"specialisten_in_communicatiev2-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:43:\"specialisten_in_communicatiev2-768x470.jpeg\";s:5:\"width\";i:768;s:6:\"height\";i:470;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:18:\"project-card-image\";a:4:{s:4:\"file\";s:43:\"specialisten_in_communicatiev2-578x357.jpeg\";s:5:\"width\";i:578;s:6:\"height\";i:357;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(158, 82, '_wp_attachment_image_alt', 'project'),
(159, 58, '_thumbnail_id', '82'),
(189, 83, '_edit_last', '3'),
(190, 83, '_edit_lock', '1640800534:3'),
(191, 83, '_wp_page_template', 'template-main.php'),
(192, 83, 'seoPageTitle', ''),
(193, 83, '_seoPageTitle', 'field_618cd353e5c8b'),
(194, 83, 'seoPageMetaDescription', ''),
(195, 83, '_seoPageMetaDescription', 'field_618cd3dfe5c8c'),
(196, 84, 'seoPageTitle', ''),
(197, 84, '_seoPageTitle', 'field_618cd353e5c8b'),
(198, 84, 'seoPageMetaDescription', ''),
(199, 84, '_seoPageMetaDescription', 'field_618cd3dfe5c8c'),
(200, 85, '_menu_item_type', 'post_type'),
(201, 85, '_menu_item_menu_item_parent', '0'),
(202, 85, '_menu_item_object_id', '83'),
(203, 85, '_menu_item_object', 'page'),
(204, 85, '_menu_item_target', ''),
(205, 85, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(206, 85, '_menu_item_xfn', ''),
(207, 85, '_menu_item_url', ''),
(209, 57, '_wp_old_date', '2021-12-09'),
(210, 79, '_wp_old_date', '2021-12-09'),
(211, 83, '_thumbnail_id', '80'),
(213, 86, '_wp_trash_meta_status', 'publish'),
(214, 86, '_wp_trash_meta_time', '1640865029'),
(227, 91, '_wp_trash_meta_status', 'publish'),
(228, 91, '_wp_trash_meta_time', '1640865515'),
(235, 95, '_wp_attached_file', '2021/12/favicon.jpg'),
(236, 95, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:512;s:6:\"height\";i:512;s:4:\"file\";s:19:\"2021/12/favicon.jpg\";s:5:\"sizes\";a:3:{s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"favicon-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"favicon-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:18:\"project-card-image\";a:4:{s:4:\"file\";s:19:\"favicon-512x357.jpg\";s:5:\"width\";i:512;s:6:\"height\";i:357;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(237, 95, '_wp_attachment_image_alt', 'Favicon'),
(238, 98, '_edit_last', '3'),
(239, 98, '_edit_lock', '1641375491:3'),
(240, 98, '_wp_page_template', 'template-main.php'),
(241, 98, 'seoPageTitle', ''),
(242, 98, '_seoPageTitle', 'field_618cd353e5c8b'),
(243, 98, 'seoPageMetaDescription', ''),
(244, 98, '_seoPageMetaDescription', 'field_618cd3dfe5c8c'),
(245, 99, 'seoPageTitle', ''),
(246, 99, '_seoPageTitle', 'field_618cd353e5c8b'),
(247, 99, 'seoPageMetaDescription', ''),
(248, 99, '_seoPageMetaDescription', 'field_618cd3dfe5c8c'),
(249, 100, '_menu_item_type', 'post_type'),
(250, 100, '_menu_item_menu_item_parent', '0'),
(251, 100, '_menu_item_object_id', '98'),
(252, 100, '_menu_item_object', 'page'),
(253, 100, '_menu_item_target', ''),
(254, 100, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(255, 100, '_menu_item_xfn', ''),
(256, 100, '_menu_item_url', ''),
(258, 57, '_wp_old_date', '2021-12-29'),
(259, 85, '_wp_old_date', '2021-12-29'),
(260, 79, '_wp_old_date', '2021-12-29'),
(261, 101, 'seoPageTitle', ''),
(262, 101, '_seoPageTitle', 'field_618cd353e5c8b'),
(263, 101, 'seoPageMetaDescription', ''),
(264, 101, '_seoPageMetaDescription', 'field_618cd3dfe5c8c'),
(265, 103, 'seoPageTitle', ''),
(266, 103, '_seoPageTitle', 'field_618cd353e5c8b'),
(267, 103, 'seoPageMetaDescription', ''),
(268, 103, '_seoPageMetaDescription', 'field_618cd3dfe5c8c'),
(269, 98, '_thumbnail_id', '80'),
(270, 104, '_edit_last', '3'),
(271, 104, '_edit_lock', '1641377425:3'),
(272, 104, '_wp_page_template', 'template-main.php'),
(273, 104, 'seoPageTitle', ''),
(274, 104, '_seoPageTitle', 'field_618cd353e5c8b'),
(275, 104, 'seoPageMetaDescription', ''),
(276, 104, '_seoPageMetaDescription', 'field_618cd3dfe5c8c'),
(277, 105, 'seoPageTitle', ''),
(278, 105, '_seoPageTitle', 'field_618cd353e5c8b'),
(279, 105, 'seoPageMetaDescription', ''),
(280, 105, '_seoPageMetaDescription', 'field_618cd3dfe5c8c'),
(281, 104, '_wp_trash_meta_status', 'publish'),
(282, 104, '_wp_trash_meta_time', '1641377578'),
(283, 104, '_wp_desired_post_slug', '404-2'),
(285, 72, '_thumbnail_id', '80');

-- --------------------------------------------------------

--
-- Table structure for table `wp_posts`
--

CREATE TABLE `wp_posts` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `post_author` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_posts`
--

INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 3, '2021-11-02 09:15:16', '2021-11-02 09:15:16', '<!-- wp:paragraph -->\n<p>Welkom bij WordPress. Dit is je eerste bericht. Bewerk of verwijder het, start dan met schrijven!</p>\n<!-- /wp:paragraph -->', 'Hallo wereld!', '', 'publish', 'open', 'open', '', 'hallo-wereld', '', '', '2021-11-02 09:15:16', '2021-11-02 09:15:16', '', 0, 'http://localhost:8888/?p=1', 0, 'post', '', 1),
(2, 3, '2021-11-02 09:15:16', '2021-11-02 09:15:16', '<!-- wp:paragraph -->\r\n<p>Dit is een boilerplate.</p>\r\n<!-- /wp:paragraph -->', 'Home', '', 'publish', 'closed', 'closed', '', 'voorbeeld-pagina', '', '', '2021-12-09 22:42:58', '2021-12-09 21:42:58', '', 0, 'http://localhost:8888/?page_id=2', 0, 'page', '', 0),
(7, 3, '2021-11-02 09:18:38', '2021-11-02 09:18:38', '<!-- wp:paragraph -->\r\n<p>Dit is een voorbeeldpagina. Het is anders dan een blog bericht omdat het op één plek blijft en tevoorschijn komt in je site navigatie (in de meeste thema\'s). De meeste mensen starten met een Over pagina dat hen voorstelt aan potentiële site bezoekers. Het zou iets als dit kunnen zeggen:</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:quote -->\r\n<blockquote class=\"wp-block-quote\">\r\n<p>Hoi daar! Ik ben een fietskoerier in het dagelijks leven en een beginnende acteur in de avonduren, en dit is mijn site. Ik leef in Los Angeles, heb een leuke hond genaamd Jack en ik hou van piña coladas. (En overvallen worden door de regen.)</p>\r\n</blockquote>\r\n<!-- /wp:quote -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>...of zoiets als dit:</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:quote -->\r\n<blockquote class=\"wp-block-quote\">\r\n<p>De XYZ Doohickey Company is opgericht in 1971 en heeft sindsdien kwalitatieve doohickeys aan het publiek geleverd. Gevestigd in Gotham City, heeft XYZ meer dan 2000 mensen in dienst en doet allerlei fantastische dingen voor de community in Gotham.</p>\r\n</blockquote>\r\n<!-- /wp:quote -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>Als nieuwe WordPress gebruiker kan je naar <a href=\"http://localhost:8888/wp-admin/\">je dashboard</a> gaan om deze pagina te verwijderen en nieuwe pagina\'s toe te voegen voor je inhoud. Veel plezier!</p>\r\n<!-- /wp:paragraph -->', 'Voorbeeld pagina', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2021-11-02 09:18:38', '2021-11-02 09:18:38', '', 2, 'http://localhost:8888/?p=7', 0, 'revision', '', 0),
(9, 3, '2021-11-02 09:19:43', '2021-11-02 09:19:43', '<div class=\"form-col\">\r\n  [honeypot honeypot-208 id:email]\r\n</div>\r\n\r\n<div class=\"form-col\">\r\n  [text* first_name id:first_name]\r\n  <label for=\"first_name\">Voornaam</label>\r\n</div>\r\n\r\n<div class=\"form-col\">\r\n  [text* last_name id:last_name]\r\n  <label for=\"last_name\">Achternaam</label>\r\n</div>\r\n\r\n<div class=\"form-col\">\r\n  [tel* phone id:phone]\r\n  <label for=\"phone\">Telefoonnummer</label>\r\n</div>\r\n\r\n<div class=\"form-col\">\r\n  [email* email_real id:email_real]\r\n  <label for=\"email_real\">E-mail adres</label>\r\n</div>\r\n\r\n<div class=\"form-col\">\r\n  [text* subject id:subject]\r\n  <label for=\"subject\">Onderwerp</label>\r\n</div>\r\n\r\n<div class=\"form-col form-textarea-col\">\r\n  [textarea* message id:message]\r\n  <label for=\"message\">Bericht</label>\r\n</div>\r\n\r\n<div class=\"form-col form-submit-col\">\r\n  [submit \"Submit\"]\r\n</div>\n1\n[_site_title] \"[subject]\"\n[_site_title] <webbeheer@bureauhanze.nl>\n[_site_admin_email]\n<html lang=\"en\">\r\n<head>\r\n    <meta charset=\"UTF-8\">\r\n    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">\r\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n    <title>E-mail template</title>\r\n    <link rel=\"preconnect\" href=\"https://fonts.googleapis.com\">\r\n    <link rel=\"preconnect\" href=\"https://fonts.gstatic.com\" crossorigin>\r\n    <link href=\"https://fonts.googleapis.com/css2?family=Open+Sans&display=swap\" rel=\"stylesheet\">\r\n</head>\r\n<body>\r\n    \r\n\r\n<div class=\"page-wrapper\">\r\n\r\n    <header class=\"header\">\r\n        <div class=\"container\">\r\n            <div class=\"row\">\r\n                <img class=\"header-logo\" src=\"/wp-content/themes/bureauhanze/assets/img/favicon.jpg\" alt=\"Favicon\">\r\n            </div>\r\n        </div>\r\n    </header>\r\n    \r\n    <div class=\"sender-information\">\r\n        <div class=\"container\">\r\n            <div class=\"row\">\r\n                <h1>Nieuwe contactaanvraag.</h1>\r\n                <div class=\"sender-items\">\r\n                    <p class=\"sender-item\">Naam:</p>\r\n                    <p class=\"sender-result\">[first_name] [last_name]</p>\r\n                </div>\r\n                <div class=\"sender-items\">\r\n                    <p class=\"sender-item\">E-mail adres:</p>\r\n                    <p class=\"sender-result\">[email_real]</p>\r\n                </div>\r\n                <div class=\"sender-items\">\r\n                    <p class=\"sender-item\">Telefoonnummer:</p>\r\n                    <p class=\"sender-result\">[phone]</p>\r\n                </div>\r\n                <div class=\"sender-items\">\r\n                    <p class=\"sender-item\">Onderwerp:</p>\r\n                    <p class=\"sender-result\">[subject]</p>\r\n                </div>\r\n                <div class=\"sender-items\">\r\n                    <p class=\"sender-item sender-item-span\">Bericht:</p>\r\n                    <p class=\"sender-result\">[message]</p>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n\r\n    <div class=\"seperator\"></div>\r\n\r\n    <footer class=\"footer\">\r\n    \r\n        <div class=\"container\">\r\n            <div class=\"row\">\r\n                <div class=\"footer-contact\">\r\n                    <h2>Contact.</h2>\r\n                    <p>Broeklandstraaat 16</p>\r\n                    <p>8082 AE Elburg</p>\r\n                    <a href=\"https://bureauhanze.nl\" title=\"\">Bekijk hier onze website.</a>\r\n                    <div class=\"footer-buttons\">\r\n                        <a class=\"main-navigation__phone contact-phone\" href=\"tel:+31850640200\" target=\"\" title=\"Bel met ons\" rel=\"noopener\">\r\n                        <svg width=\"15px\" height=\"16px\" viewBox=\"0 0 15 16\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\">\r\n                            <title>phone-icon</title>\r\n                            <g id=\"Page-1\" stroke=\"none\" stroke-width=\"1\" fill=\"none\" fill-rule=\"evenodd\">\r\n                                <g id=\"Home\" transform=\"translate(-1034.000000, -35.000000)\" fill-rule=\"nonzero\">\r\n                                    <g id=\"phone-icon\" transform=\"translate(1034.000000, 35.000000)\">\r\n                                        <path d=\"M14.1145199,10.3069889 C14.1499391,7.75680607 13.1582013,5.41913849 11.4934986,3.6835974 L12.1310443,3.0460517 C13.0519437,4.00237026 13.7603278,5.10036563 14.2561967,6.30461863 C14.7520656,7.57971004 15,8.92563986 15,10.2715697 L14.1145199,10.3069889 Z\" class=\"phone1\" fill=\"currentcolor\"></path>\r\n                                        <path d=\"M11.1747258,10.2715697 C11.210145,8.5360286 10.5371801,6.94216434 9.40376548,5.77333054 L10.0413112,5.13578484 C11.387241,6.51713387 12.0956251,8.32351336 12.0602059,10.2715697 L11.1747258,10.2715697 Z\" id=\"Path\" class=\"phone2\" ></path>\r\n                                        <path d=\"M11.8831099,13.8843287 L11.1038874,14.6635512 C10.7142761,15.0531625 10.182988,15.2302585 9.54544231,15.1948393 C8.97873501,15.1948393 8.34118931,15.0177433 7.63280519,14.7343896 C6.25145617,14.1676823 4.76384952,13.0696869 3.4179197,11.6883379 L5.29513761,9.81112001 C6.07436014,10.5903425 6.92442108,11.2987266 7.73906281,11.8654339 L8.8724774,10.7674386 C9.22666946,10.4486657 9.79337675,10.4486657 10.1121496,10.8028578 L11.8831099,12.6446565 C12.2373019,12.9988485 12.2373019,13.5655558 11.8831099,13.8843287 Z\" class=\"phone3\"  fill=\"currentcolor\"></path>\r\n                                        <path d=\"M10.005892,5.13578484 C8.65996216,3.75443581 6.85358267,2.97521329 4.94094555,2.93979408 L4.94094555,3.82527423 C6.71190584,3.86069343 8.2703509,4.60449675 9.40376548,5.77333054 L10.005892,5.13578484 L10.005892,5.13578484 Z\" class=\"phone4\"  fill=\"currentcolor\"></path>\r\n                                        <path d=\"M8.94331581,0.850060939 C7.70364361,0.283353646 6.35771379,0 4.97636476,0 L4.97636476,0.885480145 C7.52654758,0.920899351 9.86421516,2.01889473 11.4934986,3.71901661 L12.1310443,3.0814709 C11.210145,2.12515235 10.1475688,1.38134903 8.94331581,0.850060939 Z\" class=\"phone4\"  fill=\"currentcolor\"></path>\r\n                                        <path d=\"M5.2242992,9.7757008 C4.44507667,8.96105907 3.73669256,8.07557892 3.20540447,7.19009878 L4.33881905,6.0921034 C4.69301111,5.73791134 4.69301111,5.20662325 4.37423826,4.85243119 L2.60327797,3.01063249 C2.21366671,2.62102123 1.68237862,2.65644043 1.36360577,2.97521329 L0.58438324,3.71901661 C-0.124000876,4.42740072 -0.194839287,5.63165372 0.407287211,7.19009878 C0.938575298,8.60686701 2.00115147,10.1653121 3.3825005,11.5820803 L3.45333891,11.6529187 L5.33055682,9.7757008 L5.2242992,9.7757008 Z\" class=\"phone6\"  fill=\"currentcolor\"></path>\r\n                                    </g>\r\n                                </g>\r\n                            </g>\r\n                        </svg>\r\n                        085 06 40 200\r\n                        </a>\r\n                        <a class=\"main-navigation__mail contact-mail\" href=\"mailto:webbeheer@bureauhanze.nl\" target=\"\" title=\"webbeheer@bureauhanze.nl\" rel=\"noopener\"><svg width=\"19px\" height=\"15px\" viewBox=\"0 0 19 15\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\">\r\n                            <title>Group 4</title>\r\n                            <g id=\"Page-1\" stroke=\"none\" stroke-width=\"1\" fill=\"none\" fill-rule=\"evenodd\">\r\n                                <g id=\"Home\" transform=\"translate(-1204.000000, -35.000000)\">\r\n                                    <g id=\"Group-4\" transform=\"translate(1213.407283, 42.809046) rotate(-9.000000) translate(-1213.407283, -42.809046) translate(1205.000000, 37.000000)\">\r\n                                        <polygon class=\"envelope-top\" fill=\"currentcolor\" points=\"8.40730434 7.31182735 4.36740814e-05 1.50361127 4.36740814e-05 11.6180918 16.814565 11.6180918 16.814565 1.50361127\"></polygon>\r\n                                        <polygon class=\"envelope-bottom\" fill=\"currentcolor\" points=\"-6.66548334e-14 -2.87804946e-14 8.40726066 5.80865282 16.8145213 -2.87804946e-14\"></polygon>\r\n                                    </g>\r\n                                </g>\r\n                            </g>\r\n                        </svg>webbeheer@bureauhanze.nl\r\n                        </a>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n\r\n    </footer>\r\n\r\n</div>\r\n\r\n</body>\r\n</html>\r\n\r\n<style>\r\n\r\n* {\r\n    box-sizing: border-box;\r\n}\r\nbody {\r\n    font-family: \'Open Sans\', sans-serif;\r\n}\r\n.page-wrapper {\r\n    margin: 32px;\r\n    max-width: 640px;\r\n    margin-left: auto;\r\n    margin-right: auto;\r\n    box-shadow: rgba(149, 157, 165, 0.2) 0px 8px 24px;\r\n}\r\n.container {\r\n    width: 100%;\r\n    padding: 16px 64px;\r\n    background: white;\r\n}\r\nh1,h2 {\r\n    margin-top: 0;\r\n    font-weight: bold;\r\n    color: black;\r\n}\r\nh1 {\r\n    margin-bottom: 32px;\r\n    font-size: 24px;\r\n}\r\nh2 {\r\n    font-size: 18px;\r\n}\r\np,a {\r\n    font-size: 16px;\r\n}\r\np {\r\n    color: black;\r\n    margin: 0;\r\n    line-height: 1.3;\r\n}\r\na {\r\n    color: black;\r\n    text-decoration: none;\r\n}\r\na:hover {\r\n    text-decoration: underline;\r\n}\r\n.row {\r\n    position: relative;\r\n    width: 100%;\r\n}\r\nimg {\r\n    height: 100%;\r\n    width: 100%;\r\n}\r\n.seperator {\r\n    height: 1px;\r\n    width: 100%;\r\n    background-color: lightgray;\r\n    padding: 0;\r\n}\r\n.header {\r\n    background-color: #15191C;\r\n}\r\n.header-logo {\r\n    position: absolute;\r\n    top: 16px;\r\n    right: -32px;\r\n    height: auto;\r\n    object-fit: contain;\r\n    width: 48px;\r\n}\r\n.sender-items {\r\n    display: grid;\r\n    grid-template-columns: 150px 1fr;\r\n    margin-bottom: 16px;\r\n}\r\n.sender-item-span {\r\n    grid-column: 1 / span 2;\r\n}\r\n.sender-result {\r\n    font-weight: bold;\r\n}\r\n.footer-contact a {\r\n    margin-top: 16px;\r\n    display: block;\r\n}\r\n.footer-buttons {\r\n    display: flex;\r\n    gap: 32px;\r\n    margin-top: 16px;\r\n}\r\n.footer-buttons a svg{\r\n    margin-right: 8px;\r\n}\r\n@media(max-width: 768px){\r\n    .container {\r\n    padding: 32px;\r\n    }\r\n}\r\n@media(max-width: 576px){\r\n    .container {\r\n    padding: 16px;\r\n    }\r\n}\r\n</style>\nReply-To: [email_real]\n\n1\n\n\n[_site_title] \"[your-subject]\"\n[_site_title] <bartnijenhuis@bureauhanze.nl>\n[your-email]\nBerichtinhoud:\r\n[your-message]\r\n\r\n-- \r\nDeze e-mail is verzonden vanuit het contactformulier op [_site_title] [_site_url]\nReply-To: [_site_admin_email]\n\n\n\nBedankt voor je bericht. Het is verzonden.\nEr is een fout opgetreden bij het versturen van het bericht; probeer het later nog eens.\nEen of meer velden bevatten een fout; graag controleren en opnieuw proberen.\nEr is een fout opgetreden bij het versturen van het bericht; probeer het later nog eens.\nJe moet de voorwaarden accepteren voordat je het bericht kunt verzenden.\nHet veld is verplicht.\nHet veld is te lang.\nHet veld is te kort.\nEr is een onbekende fout opgetreden bij het uploaden van het bestand.\nHet is niet toegestaan dit type bestand te uploaden.\nHet bestand is te groot.\nEr is een fout opgetreden bij het uploaden van het bestand.\nDe datumnotatie is incorrect.\nDe ingevulde datum valt voor de eerst toegestane.\nDe ingevulde datum valt na de laatst toegestane.\nDe getalsnotatie is ongeldig.\nHet ingevulde getal is kleiner dan het kleinst toegestane.\nHet ingevulde getal is groter dan het hoogst toegestane.\nHet antwoord op de quiz is incorrect.\nHet ingevoerde e-mailadres is ongeldig.\nDe URL is ongeldig.\nHet telefoonnummer is ongeldig.', 'Contact', '', 'publish', 'closed', 'closed', '', 'contactformulier-1', '', '', '2022-01-05 12:06:55', '2022-01-05 11:06:55', '', 0, 'http://localhost:8888/?post_type=wpcf7_contact_form&#038;p=9', 0, 'wpcf7_contact_form', '', 0),
(10, 3, '2021-11-02 09:21:19', '2021-11-02 09:21:19', '<!-- wp:paragraph -->\r\n<p>Dit is een voorbeeldpagina. Het is anders dan een blog bericht omdat het op één plek blijft en tevoorschijn komt in je site navigatie (in de meeste thema\'s). De meeste mensen starten met een Over pagina dat hen voorstelt aan potentiële site bezoekers. Het zou iets als dit kunnen zeggen:</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:quote -->\r\n<blockquote class=\"wp-block-quote\">\r\n<p>Hoi daar! Ik ben een fietskoerier in het dagelijks leven en een beginnende acteur in de avonduren, en dit is mijn site. Ik leef in Los Angeles, heb een leuke hond genaamd Jack en ik hou van piña coladas. (En overvallen worden door de regen.)</p>\r\n</blockquote>\r\n<!-- /wp:quote -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>...of zoiets als dit:</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:quote -->\r\n<blockquote class=\"wp-block-quote\">\r\n<p>De XYZ Doohickey Company is opgericht in 1971 en heeft sindsdien kwalitatieve doohickeys aan het publiek geleverd. Gevestigd in Gotham City, heeft XYZ meer dan 2000 mensen in dienst en doet allerlei fantastische dingen voor de community in Gotham.</p>\r\n</blockquote>\r\n<!-- /wp:quote -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>Als nieuwe WordPress gebruiker kan je naar <a href=\"http://localhost:8888/wp-admin/\">je dashboard</a> gaan om deze pagina te verwijderen en nieuwe pagina\'s toe te voegen voor je inhoud. Veel plezier!</p>\r\n<!-- /wp:paragraph -->', 'Home', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2021-11-02 09:21:19', '2021-11-02 09:21:19', '', 2, 'http://localhost:8888/?p=10', 0, 'revision', '', 0),
(12, 3, '2021-11-02 09:28:17', '2021-11-02 09:28:17', '<!-- wp:paragraph -->\r\n<p>Dit is een boilerplate.</p>\r\n<!-- /wp:paragraph -->', 'Home', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2021-11-02 09:28:17', '2021-11-02 09:28:17', '', 2, 'http://localhost:8888/?p=12', 0, 'revision', '', 0),
(13, 3, '2021-11-02 09:35:37', '2021-11-02 09:35:37', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:12:\"options_page\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:22:\"theme-general-settings\";}}}s:8:\"position\";s:15:\"acf_after_title\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'Contact information', 'contact-information', 'publish', 'closed', 'closed', '', 'group_6178f42b56900', '', '', '2022-01-05 09:42:34', '2022-01-05 08:42:34', '', 0, 'http://localhost:8888/?p=13', 0, 'acf-field-group', '', 0),
(14, 3, '2021-11-02 09:35:37', '2021-11-02 09:35:37', 'a:10:{s:4:\"type\";s:8:\"textarea\";s:12:\"instructions\";s:14:\"SVG afbeelding\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:616:\"<svg width=\"512px\" height=\"512px\" viewBox=\"0 0 512 512\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\">\r\n    <title>Group</title>\r\n    <g id=\"Page-1\" stroke=\"none\" stroke-width=\"1\" fill=\"none\" fill-rule=\"evenodd\">\r\n        <g id=\"Group\">\r\n            <circle id=\"Oval\" stroke=\"#979797\" fill=\"#D8D8D8\" cx=\"256\" cy=\"256\" r=\"255.5\"></circle>\r\n            <text id=\"LOGO\" font-family=\"Helvetica-Bold, Helvetica\" font-size=\"100\" font-weight=\"bold\" fill=\"#000000\">\r\n                <tspan x=\"109.283203\" y=\"293\">LOGO</tspan>\r\n            </text>\r\n        </g>\r\n    </g>\r\n</svg>\";s:11:\"placeholder\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:4:\"rows\";s:0:\"\";s:9:\"new_lines\";s:0:\"\";}', 'Bedrijfslogo', 'contactLogo', 'publish', 'closed', 'closed', '', 'field_6179a0f70f954', '', '', '2021-11-02 09:35:37', '2021-11-02 09:35:37', '', 13, 'http://localhost:8888/?post_type=acf-field&p=14', 0, 'acf-field', '', 0),
(15, 3, '2021-11-02 09:35:37', '2021-11-02 09:35:37', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:12:\"Bedrijfsnaam\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Bedrijfsnaam', 'contactCompany', 'publish', 'closed', 'closed', '', 'field_6179044e6bd42', '', '', '2021-11-04 08:23:52', '2021-11-04 08:23:52', '', 13, 'http://localhost:8888/?post_type=acf-field&#038;p=15', 2, 'acf-field', '', 0),
(16, 3, '2021-11-02 09:35:37', '2021-11-02 09:35:37', 'a:6:{s:4:\"type\";s:4:\"link\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:2:\"50\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";}', 'Telefoonnummer', 'contactPhone', 'publish', 'closed', 'closed', '', 'field_6178f45566dc9', '', '', '2022-01-05 09:33:47', '2022-01-05 08:33:47', '', 13, 'http://localhost:8888/?post_type=acf-field&#038;p=16', 9, 'acf-field', '', 0),
(17, 3, '2021-11-02 09:35:37', '2021-11-02 09:35:37', 'a:6:{s:4:\"type\";s:4:\"link\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:2:\"50\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";}', 'E-mail adres', 'contactMail', 'publish', 'closed', 'closed', '', 'field_6178fde2cb3d0', '', '', '2022-01-05 09:33:47', '2022-01-05 08:33:47', '', 13, 'http://localhost:8888/?post_type=acf-field&#038;p=17', 10, 'acf-field', '', 0),
(18, 3, '2021-11-02 09:35:37', '2021-11-02 09:35:37', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:13:\"Straatnaam 11\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Adres', 'contactAddress', 'publish', 'closed', 'closed', '', 'field_6178ff949ba6f', '', '', '2021-12-06 14:37:05', '2021-12-06 14:37:05', '', 13, 'http://localhost:8888/?post_type=acf-field&#038;p=18', 5, 'acf-field', '', 0),
(19, 3, '2021-11-02 09:35:37', '2021-11-02 09:35:37', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:2:\"25\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:7:\"1234 AB\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Postcode', 'contactPostal', 'publish', 'closed', 'closed', '', 'field_617901e57dcd0', '', '', '2021-12-06 14:37:05', '2021-12-06 14:37:05', '', 13, 'http://localhost:8888/?post_type=acf-field&#038;p=19', 6, 'acf-field', '', 0),
(20, 3, '2021-11-02 09:35:37', '2021-11-02 09:35:37', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:2:\"75\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:6:\"Plaats\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Plaats', 'contactPlace', 'publish', 'closed', 'closed', '', 'field_617901fe7dcd1', '', '', '2021-12-06 14:37:05', '2021-12-06 14:37:05', '', 13, 'http://localhost:8888/?post_type=acf-field&#038;p=20', 7, 'acf-field', '', 0),
(21, 3, '2021-11-02 09:35:37', '2021-11-02 09:35:37', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:9:\"Nederland\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Land', 'contactCountry', 'publish', 'closed', 'closed', '', 'field_6179022a7dcd3', '', '', '2021-12-06 14:37:05', '2021-12-06 14:37:05', '', 13, 'http://localhost:8888/?post_type=acf-field&#038;p=21', 8, 'acf-field', '', 0),
(22, 3, '2021-11-02 09:35:37', '2021-11-02 09:35:37', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:12:\"options_page\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:18:\"acf-options-footer\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'Footer', 'footer', 'publish', 'closed', 'closed', '', 'group_617a6fb072c2d', '', '', '2021-12-06 15:09:39', '2021-12-06 15:09:39', '', 0, 'http://localhost:8888/?p=22', 0, 'acf-field-group', '', 0),
(25, 3, '2021-11-02 09:35:37', '2021-11-02 09:35:37', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:12:\"options_page\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:18:\"acf-options-header\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'Header', 'header', 'publish', 'closed', 'closed', '', 'group_617a72c124996', '', '', '2021-11-02 09:35:37', '2021-11-02 09:35:37', '', 0, 'http://localhost:8888/?p=25', 0, 'acf-field-group', '', 0),
(26, 3, '2021-11-02 09:35:37', '2021-11-02 09:35:37', 'a:10:{s:4:\"type\";s:8:\"textarea\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:54:\"<!-- Algemene sitetag (gtag.js) - Google Analytics -->\";s:11:\"placeholder\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:4:\"rows\";s:0:\"\";s:9:\"new_lines\";s:0:\"\";}', 'Google Analytics', 'header_google_analytics', 'publish', 'closed', 'closed', '', 'field_617a72cfdb16c', '', '', '2021-11-02 09:35:37', '2021-11-02 09:35:37', '', 25, 'http://localhost:8888/?post_type=acf-field&p=26', 0, 'acf-field', '', 0),
(54, 3, '2021-11-02 09:35:37', '2021-11-02 09:35:37', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:9:\"projecten\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'Single - Projects', 'single-projects', 'publish', 'closed', 'closed', '', 'group_617a97d33894c', '', '', '2021-11-02 09:35:37', '2021-11-02 09:35:37', '', 0, 'http://localhost:8888/?p=54', 0, 'acf-field-group', '', 0),
(55, 3, '2021-11-02 09:35:37', '2021-11-02 09:35:37', 'a:18:{s:4:\"type\";s:7:\"gallery\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:2:\"id\";s:12:\"preview_size\";s:6:\"medium\";s:6:\"insert\";s:6:\"append\";s:7:\"library\";s:3:\"all\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Project afbeeldingen', 'projects_image_gallery', 'publish', 'closed', 'closed', '', 'field_617a97f949672', '', '', '2021-11-02 09:35:37', '2021-11-02 09:35:37', '', 54, 'http://localhost:8888/?post_type=acf-field&p=55', 0, 'acf-field', '', 0),
(56, 3, '2021-11-02 09:35:37', '2021-11-02 09:35:37', 'a:7:{s:4:\"type\";s:6:\"oembed\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:5:\"width\";s:0:\"\";s:6:\"height\";s:0:\"\";}', 'Project embed url', 'project_embed', 'publish', 'closed', 'closed', '', 'field_617a9daa26965', '', '', '2021-11-02 09:35:37', '2021-11-02 09:35:37', '', 54, 'http://localhost:8888/?post_type=acf-field&p=56', 1, 'acf-field', '', 0),
(57, 3, '2022-01-05 09:54:40', '2021-11-02 10:01:22', ' ', '', '', 'publish', 'closed', 'closed', '', '57', '', '', '2022-01-05 09:54:40', '2022-01-05 08:54:40', '', 0, 'http://localhost:8888/?p=57', 1, 'nav_menu_item', '', 0),
(58, 3, '2021-11-02 10:12:03', '2021-11-02 10:12:03', 'Dit is een testproject', 'testproject', '', 'publish', 'closed', 'closed', '', 'testproject', '', '', '2021-12-09 22:44:24', '2021-12-09 21:44:24', '', 0, 'http://localhost:8888/?post_type=projecten&#038;p=58', 0, 'projecten', '', 0),
(59, 3, '2021-11-02 10:12:03', '2021-11-02 10:12:03', 'Dit is een testproject', 'testproject', '', 'inherit', 'closed', 'closed', '', '58-revision-v1', '', '', '2021-11-02 10:12:03', '2021-11-02 10:12:03', '', 58, 'http://localhost:8888/?p=59', 0, 'revision', '', 0),
(60, 3, '2021-11-04 08:17:58', '2021-11-04 08:17:58', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:23:\"https://bureauhanze.nl/\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Bedrijfswebsite URL', 'contactURL', 'publish', 'closed', 'closed', '', 'field_618396f0c65bc', '', '', '2021-11-04 08:30:39', '2021-11-04 08:30:39', '', 13, 'http://localhost:8888/?post_type=acf-field&#038;p=60', 4, 'acf-field', '', 0),
(61, 3, '2021-11-04 08:23:52', '2021-11-04 08:23:52', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:19:\".jpg in 512px 512px\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";i:512;s:10:\"min_height\";i:512;s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";i:512;s:10:\"max_height\";i:512;s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Favicon', 'contactFavicon', 'publish', 'closed', 'closed', '', 'field_61839829b75c6', '', '', '2021-11-04 08:24:45', '2021-11-04 08:24:45', '', 13, 'http://localhost:8888/?post_type=acf-field&#038;p=61', 1, 'acf-field', '', 0),
(62, 3, '2021-11-04 08:27:17', '2021-11-04 08:27:17', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:24:\"WordPress webdevelopment\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Bedrijfsslogan', 'contactSlogan', 'publish', 'closed', 'closed', '', 'field_6183993918c48', '', '', '2021-11-04 08:27:51', '2021-11-04 08:27:51', '', 13, 'http://localhost:8888/?post_type=acf-field&#038;p=62', 3, 'acf-field', '', 0),
(68, 3, '2021-11-11 08:29:19', '2021-11-11 08:29:19', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:13:\"page_template\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:17:\"template-main.php\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'SEO', 'seo', 'publish', 'closed', 'closed', '', 'group_618cd33f7275e', '', '', '2021-11-17 18:42:39', '2021-11-17 18:42:39', '', 0, 'http://localhost:8888/?post_type=acf-field-group&#038;p=68', 0, 'acf-field-group', '', 0),
(69, 3, '2021-11-11 08:29:19', '2021-11-11 08:29:19', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:19:\"Max. 60 characters.\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";i:60;}', 'Page Title', 'seoPageTitle', 'publish', 'closed', 'closed', '', 'field_618cd353e5c8b', '', '', '2021-11-11 08:52:01', '2021-11-11 08:52:01', '', 68, 'http://localhost:8888/?post_type=acf-field&#038;p=69', 0, 'acf-field', '', 0),
(70, 3, '2021-11-11 08:29:19', '2021-11-11 08:29:19', 'a:10:{s:4:\"type\";s:8:\"textarea\";s:12:\"instructions\";s:20:\"Max. 120 characters.\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:4:\"rows\";i:2;s:9:\"new_lines\";s:0:\"\";}', 'Page Meta Description', 'seoPageMetaDescription', 'publish', 'closed', 'closed', '', 'field_618cd3dfe5c8c', '', '', '2021-11-11 08:52:41', '2021-11-11 08:52:41', '', 68, 'http://localhost:8888/?post_type=acf-field&#038;p=70', 1, 'acf-field', '', 0),
(72, 3, '2021-11-17 18:58:41', '2021-11-17 18:58:41', '', 'Cheatsheet', '', 'publish', 'closed', 'closed', '', 'cheatsheet', '', '', '2022-01-05 12:32:55', '2022-01-05 11:32:55', '', 0, 'http://localhost:8888/?page_id=72', 0, 'page', '', 0),
(73, 3, '2021-11-17 18:58:41', '2021-11-17 18:58:41', '', 'cheatsheet', '', 'inherit', 'closed', 'closed', '', '72-revision-v1', '', '', '2021-11-17 18:58:41', '2021-11-17 18:58:41', '', 72, 'http://localhost:8888/?p=73', 0, 'revision', '', 0),
(74, 3, '2021-12-06 14:04:44', '2021-12-06 14:04:44', 'a:6:{s:4:\"type\";s:4:\"link\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:2:\"50\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";}', 'Facebook', 'contactFacebook', 'publish', 'closed', 'closed', '', 'field_61ae1855e55de', '', '', '2022-01-05 09:33:47', '2022-01-05 08:33:47', '', 13, 'http://localhost:8888/?post_type=acf-field&#038;p=74', 13, 'acf-field', '', 0),
(75, 3, '2021-12-06 14:08:04', '2021-12-06 14:08:04', 'a:6:{s:4:\"type\";s:4:\"link\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:2:\"50\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";}', 'LinkedIn', 'contactLinkedIn', 'publish', 'closed', 'closed', '', 'field_61ae19337923c', '', '', '2022-01-05 09:33:47', '2022-01-05 08:33:47', '', 13, 'http://localhost:8888/?post_type=acf-field&#038;p=75', 14, 'acf-field', '', 0),
(76, 3, '2021-12-06 14:08:04', '2021-12-06 14:08:04', 'a:6:{s:4:\"type\";s:4:\"link\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:2:\"50\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";}', 'YoutTube', 'contactYouTube', 'publish', 'closed', 'closed', '', 'field_61ae19147923b', '', '', '2022-01-05 09:33:47', '2022-01-05 08:33:47', '', 13, 'http://localhost:8888/?post_type=acf-field&#038;p=76', 15, 'acf-field', '', 0),
(77, 3, '2021-12-06 14:27:44', '2021-12-06 14:27:44', 'a:6:{s:4:\"type\";s:4:\"link\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:2:\"50\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";}', 'Instagram', 'contactInstagram', 'publish', 'closed', 'closed', '', 'field_61ae1dd1cdbe4', '', '', '2022-01-05 09:33:47', '2022-01-05 08:33:47', '', 13, 'http://localhost:8888/?post_type=acf-field&#038;p=77', 16, 'acf-field', '', 0),
(78, 3, '2021-12-07 16:42:35', '2021-12-07 15:42:35', 'a:6:{s:4:\"type\";s:4:\"link\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:2:\"50\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";}', 'Whatsapp', 'contactWhatsApp', 'publish', 'closed', 'closed', '', 'field_61af80d7ba22f', '', '', '2022-01-05 09:33:47', '2022-01-05 08:33:47', '', 13, 'http://localhost:8888/?post_type=acf-field&#038;p=78', 17, 'acf-field', '', 0),
(79, 3, '2022-01-05 09:54:40', '2021-12-09 20:27:38', ' ', '', '', 'publish', 'closed', 'closed', '', '79', '', '', '2022-01-05 09:54:40', '2022-01-05 08:54:40', '', 0, 'http://localhost:8888/?p=79', 4, 'nav_menu_item', '', 0),
(80, 3, '2021-12-09 22:42:16', '2021-12-09 21:42:16', '', 'bureauhanze', '', 'inherit', 'closed', 'closed', '', 'bureauhanze', '', '', '2021-12-09 22:42:23', '2021-12-09 21:42:23', '', 2, 'http://localhost:8888/wp-content/uploads/2021/12/bureauhanze.jpeg', 0, 'attachment', 'image/jpeg', 0),
(81, 3, '2021-12-09 22:42:58', '2021-12-09 21:42:58', '<!-- wp:paragraph -->\r\n<p>Dit is een boilerplate.</p>\r\n<!-- /wp:paragraph -->', 'Home', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2021-12-09 22:42:58', '2021-12-09 21:42:58', '', 2, 'http://localhost:8888/?p=81', 0, 'revision', '', 0),
(82, 3, '2021-12-09 22:44:10', '2021-12-09 21:44:10', '', 'project', '', 'inherit', 'closed', 'closed', '', 'specialisten_in_communicatiev2', '', '', '2021-12-09 22:44:22', '2021-12-09 21:44:22', '', 58, 'http://localhost:8888/wp-content/uploads/2021/11/specialisten_in_communicatiev2.jpeg', 0, 'attachment', 'image/jpeg', 0),
(83, 3, '2021-12-29 18:57:14', '2021-12-29 17:57:14', '', 'Contact', '', 'publish', 'closed', 'closed', '', 'contact', '', '', '2021-12-29 18:57:57', '2021-12-29 17:57:57', '', 0, 'http://localhost:8888/?page_id=83', 0, 'page', '', 0),
(84, 3, '2021-12-29 18:57:14', '2021-12-29 17:57:14', '', 'Contact', '', 'inherit', 'closed', 'closed', '', '83-revision-v1', '', '', '2021-12-29 18:57:14', '2021-12-29 17:57:14', '', 83, 'http://localhost:8888/?p=84', 0, 'revision', '', 0),
(85, 3, '2022-01-05 09:54:40', '2021-12-29 17:57:35', ' ', '', '', 'publish', 'closed', 'closed', '', '85', '', '', '2022-01-05 09:54:40', '2022-01-05 08:54:40', '', 0, 'http://localhost:8888/?p=85', 2, 'nav_menu_item', '', 0),
(86, 3, '2021-12-30 12:50:29', '2021-12-30 11:50:29', '{\n    \"site_icon\": {\n        \"value\": \"\",\n        \"type\": \"option\",\n        \"user_id\": 3,\n        \"date_modified_gmt\": \"2021-12-30 11:50:29\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'c2c935e7-2ed9-423d-a747-2228a35b8ec2', '', '', '2021-12-30 12:50:29', '2021-12-30 11:50:29', '', 0, 'http://localhost:8888/c2c935e7-2ed9-423d-a747-2228a35b8ec2/', 0, 'customize_changeset', '', 0),
(91, 3, '2021-12-30 12:58:35', '2021-12-30 11:58:35', '{\n    \"site_icon\": {\n        \"value\": 90,\n        \"type\": \"option\",\n        \"user_id\": 3,\n        \"date_modified_gmt\": \"2021-12-30 11:58:35\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '1d872d87-53a1-4ceb-899b-754a2ede461b', '', '', '2021-12-30 12:58:35', '2021-12-30 11:58:35', '', 0, 'http://localhost:8888/1d872d87-53a1-4ceb-899b-754a2ede461b/', 0, 'customize_changeset', '', 0),
(95, 3, '2021-12-30 13:06:04', '2021-12-30 12:06:04', '', 'Favicon', '', 'inherit', 'closed', 'closed', '', 'favicon', '', '', '2021-12-30 13:06:51', '2021-12-30 12:06:51', '', 0, 'http://localhost:8888/wp-content/uploads/2021/12/favicon.jpg', 0, 'attachment', 'image/jpeg', 0),
(96, 3, '2022-01-05 09:33:47', '2022-01-05 08:33:47', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:27:\"Kamer van Koophandel nummer\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:2:\"50\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'KvK', 'contactKvK', 'publish', 'closed', 'closed', '', 'field_61d5577a78ad9', '', '', '2022-01-05 09:42:34', '2022-01-05 08:42:34', '', 13, 'http://localhost:8888/?post_type=acf-field&#038;p=96', 11, 'acf-field', '', 0),
(97, 3, '2022-01-05 09:33:47', '2022-01-05 08:33:47', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:10:\"BTW nummer\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:2:\"50\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'BTW', 'contactBTW', 'publish', 'closed', 'closed', '', 'field_61d557a978ada', '', '', '2022-01-05 09:42:34', '2022-01-05 08:42:34', '', 13, 'http://localhost:8888/?post_type=acf-field&#038;p=97', 12, 'acf-field', '', 0),
(98, 3, '2022-01-05 09:52:01', '2022-01-05 08:52:01', '', 'Privacy statement', '', 'publish', 'closed', 'closed', '', 'privacy-statement', '', '', '2022-01-05 09:58:10', '2022-01-05 08:58:10', '', 0, 'http://localhost:8888/?page_id=98', 0, 'page', '', 0),
(99, 3, '2022-01-05 09:52:01', '2022-01-05 08:52:01', '', 'privacy-statement', '', 'inherit', 'closed', 'closed', '', '98-revision-v1', '', '', '2022-01-05 09:52:01', '2022-01-05 08:52:01', '', 98, 'http://localhost:8888/?p=99', 0, 'revision', '', 0),
(100, 3, '2022-01-05 09:54:40', '2022-01-05 08:53:14', ' ', '', '', 'publish', 'closed', 'closed', '', 'privacy-statement', '', '', '2022-01-05 09:54:40', '2022-01-05 08:54:40', '', 0, 'http://localhost:8888/?p=100', 3, 'nav_menu_item', '', 0),
(101, 3, '2022-01-05 09:53:58', '2022-01-05 08:53:58', '', 'Privacy-statement', '', 'inherit', 'closed', 'closed', '', '98-revision-v1', '', '', '2022-01-05 09:53:58', '2022-01-05 08:53:58', '', 98, 'http://localhost:8888/?p=101', 0, 'revision', '', 0),
(102, 3, '2022-01-05 09:54:04', '2022-01-05 08:54:04', '', 'Cheatsheet', '', 'inherit', 'closed', 'closed', '', '72-revision-v1', '', '', '2022-01-05 09:54:04', '2022-01-05 08:54:04', '', 72, 'http://localhost:8888/?p=102', 0, 'revision', '', 0),
(103, 3, '2022-01-05 09:54:19', '2022-01-05 08:54:19', '', 'Privacy statement', '', 'inherit', 'closed', 'closed', '', '98-revision-v1', '', '', '2022-01-05 09:54:19', '2022-01-05 08:54:19', '', 98, 'http://localhost:8888/?p=103', 0, 'revision', '', 0),
(104, 3, '2022-01-05 11:12:44', '2022-01-05 10:12:44', '', '404', '', 'trash', 'closed', 'closed', '', '404-2__trashed', '', '', '2022-01-05 11:12:58', '2022-01-05 10:12:58', '', 0, 'http://localhost:8888/?page_id=104', 0, 'page', '', 0),
(105, 3, '2022-01-05 11:12:44', '2022-01-05 10:12:44', '', '404', '', 'inherit', 'closed', 'closed', '', '104-revision-v1', '', '', '2022-01-05 11:12:44', '2022-01-05 10:12:44', '', 104, 'http://localhost:8888/?p=105', 0, 'revision', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_termmeta`
--

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_terms`
--

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_terms`
--

INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Niet gecategoriseerd', 'niet-gecategoriseerd', 0),
(2, 'main', 'main', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_relationships`
--

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_term_relationships`
--

INSERT INTO `wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(13, 1, 0),
(22, 1, 0),
(25, 1, 0),
(27, 1, 0),
(32, 1, 0),
(37, 1, 0),
(42, 1, 0),
(46, 1, 0),
(51, 1, 0),
(54, 1, 0),
(57, 2, 0),
(79, 2, 0),
(85, 2, 0),
(100, 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_taxonomy`
--

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_term_taxonomy`
--

INSERT INTO `wp_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'nav_menu', '', 0, 4);

-- --------------------------------------------------------

--
-- Table structure for table `wp_usermeta`
--

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_usermeta`
--

INSERT INTO `wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(37, 3, 'nickname', 'admin'),
(38, 3, 'first_name', ''),
(39, 3, 'last_name', ''),
(40, 3, 'description', ''),
(41, 3, 'rich_editing', 'true'),
(42, 3, 'syntax_highlighting', 'true'),
(43, 3, 'comment_shortcuts', 'false'),
(44, 3, 'admin_color', 'fresh'),
(45, 3, 'use_ssl', '0'),
(46, 3, 'show_admin_bar_front', 'false'),
(47, 3, 'locale', ''),
(48, 3, 'wp_capabilities', 'a:1:{s:13:\"administrator\";b:1;}'),
(49, 3, 'wp_user_level', '10'),
(50, 3, 'dismissed_wp_pointers', ''),
(51, 3, 'session_tokens', 'a:2:{s:64:\"acc1dc57eca7e6ef4628bedeb69c5d503b40901aaea7acddf49dd49539aa3f3d\";a:4:{s:10:\"expiration\";i:1642581022;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:121:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36\";s:5:\"login\";i:1641371422;}s:64:\"4bea211fcc7b34f7a045ed25ce69c2fe2b4fe310e2e31f363d9852506eb6d2d1\";a:4:{s:10:\"expiration\";i:1641985615;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:121:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36\";s:5:\"login\";i:1641812815;}}'),
(52, 3, 'community-events-location', 'a:1:{s:2:\"ip\";s:9:\"127.0.0.0\";}'),
(53, 3, 'nav_menu_recently_edited', '2'),
(54, 3, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}'),
(55, 3, 'metaboxhidden_nav-menus', 'a:3:{i:0;s:23:\"add-post-type-projecten\";i:1;s:12:\"add-post_tag\";i:2;s:20:\"add-project_category\";}'),
(56, 3, 'wp_user-settings', 'libraryContent=browse'),
(57, 3, 'wp_user-settings-time', '1639086140'),
(58, 3, 'wp_media_library_mode', 'grid'),
(59, 3, 'meta-box-order_dashboard', 'a:4:{s:6:\"normal\";s:41:\"ia_dashboard_widget,dashboard_site_health\";s:4:\"side\";s:19:\"dashboard_right_now\";s:7:\"column3\";s:0:\"\";s:7:\"column4\";s:0:\"\";}');

-- --------------------------------------------------------

--
-- Table structure for table `wp_users`
--

CREATE TABLE `wp_users` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_users`
--

INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(3, 'admin', '$P$BYT9ZCEEJWWpH0SchYHWmk7znHXA4S0', 'admin', 'webbeheer@bureauhanze.nl', '', '2021-11-11 08:23:33', '1636619013:$P$BshfIJf1BXVU5RIbg0N0aRFz8wmv0e/', 0, 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_comments`
--
ALTER TABLE `wp_comments`
  ADD PRIMARY KEY (`comment_ID`),
  ADD KEY `comment_post_ID` (`comment_post_ID`),
  ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  ADD KEY `comment_date_gmt` (`comment_date_gmt`),
  ADD KEY `comment_parent` (`comment_parent`),
  ADD KEY `comment_author_email` (`comment_author_email`(10));

--
-- Indexes for table `wp_links`
--
ALTER TABLE `wp_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `link_visible` (`link_visible`);

--
-- Indexes for table `wp_options`
--
ALTER TABLE `wp_options`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `option_name` (`option_name`),
  ADD KEY `autoload` (`autoload`);

--
-- Indexes for table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_posts`
--
ALTER TABLE `wp_posts`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `post_name` (`post_name`(191)),
  ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  ADD KEY `post_parent` (`post_parent`),
  ADD KEY `post_author` (`post_author`);

--
-- Indexes for table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `term_id` (`term_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_terms`
--
ALTER TABLE `wp_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD KEY `slug` (`slug`(191)),
  ADD KEY `name` (`name`(191));

--
-- Indexes for table `wp_term_relationships`
--
ALTER TABLE `wp_term_relationships`
  ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Indexes for table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  ADD PRIMARY KEY (`term_taxonomy_id`),
  ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  ADD KEY `taxonomy` (`taxonomy`);

--
-- Indexes for table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  ADD PRIMARY KEY (`umeta_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_users`
--
ALTER TABLE `wp_users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_login_key` (`user_login`),
  ADD KEY `user_nicename` (`user_nicename`),
  ADD KEY `user_email` (`user_email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_comments`
--
ALTER TABLE `wp_comments`
  MODIFY `comment_ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wp_links`
--
ALTER TABLE `wp_links`
  MODIFY `link_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_options`
--
ALTER TABLE `wp_options`
  MODIFY `option_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=674;

--
-- AUTO_INCREMENT for table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=286;

--
-- AUTO_INCREMENT for table `wp_posts`
--
ALTER TABLE `wp_posts`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=106;

--
-- AUTO_INCREMENT for table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_terms`
--
ALTER TABLE `wp_terms`
  MODIFY `term_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  MODIFY `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  MODIFY `umeta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT for table `wp_users`
--
ALTER TABLE `wp_users`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
